package co.edu.unbosque.model;

public class ReptilDTO extends AnimalDTO{
	
	private int cantidadDePatas;
	
	public ReptilDTO() {
		// TODO Auto-generated constructor stub
	}

	public ReptilDTO(int cantidadDePatas) {
		super();
		this.cantidadDePatas = cantidadDePatas;
	}

	public ReptilDTO(String nombre, int edadMeses, float pesoKg, int cantidadDePatas) {
		super(nombre, edadMeses, pesoKg);
		this.cantidadDePatas = cantidadDePatas;
	}

	public int getCantidadDePatas() {
		return cantidadDePatas;
	}

	public void setCantidadDePatas(int cantidadDePatas) {
		this.cantidadDePatas = cantidadDePatas;
	}

	public ReptilDTO(String nombre, int edadMeses, float pesoKg) {
		super(nombre, edadMeses, pesoKg);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "ReptilDTO [cantidadDePatas=" + cantidadDePatas + "]";
	}
	
	
	
	

}
