package co.edu.unbosque.model;

public abstract class AnimalDTO {
	
	private String nombre;
	private int edadMeses;
	private float pesoKg;
	
	public AnimalDTO() {
		// TODO Auto-generated constructor stub
	}

	public AnimalDTO(String nombre, int edadMeses, float pesoKg) {
		super();
		this.nombre = nombre;
		this.edadMeses = edadMeses;
		this.pesoKg = pesoKg;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdadMeses() {
		return edadMeses;
	}

	public void setEdadMeses(int edadMeses) {
		this.edadMeses = edadMeses;
	}

	public float getPesoKg() {
		return pesoKg;
	}

	public void setPesoKg(float pesoKg) {
		this.pesoKg = pesoKg;
	}

	@Override
	public String toString() {
		return "AnimalDTO [nombre=" + nombre + ", edadMeses=" + edadMeses + ", pesoKg=" + pesoKg + "]";
	}
	
	
	
}
