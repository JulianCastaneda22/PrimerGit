package co.edu.unbosque.model;

public class MamiferoDTO extends AnimalDTO {
	
	private String tipoDePelaje;
	
	public MamiferoDTO() {
		// TODO Auto-generated constructor stub
	}

	public MamiferoDTO(String tipoDePelaje) {
		super();
		this.tipoDePelaje = tipoDePelaje;
	}

	public MamiferoDTO(String nombre, int edadMeses, float pesoKg, String tipoDePelaje) {
		super(nombre, edadMeses, pesoKg);
		this.tipoDePelaje = tipoDePelaje;
	}

	public MamiferoDTO(String nombre, int edadMeses, float pesoKg) {
		super(nombre, edadMeses, pesoKg);
		// TODO Auto-generated constructor stub
	}

	public String getTipoDePelaje() {
		return tipoDePelaje;
	}

	public void setTipoDePelaje(String tipoDePelaje) {
		this.tipoDePelaje = tipoDePelaje;
	}

	@Override
	public String toString() {
		return "MamiferoDTO [tipoDePelaje=" + tipoDePelaje + "]";
	}
	
	

}
