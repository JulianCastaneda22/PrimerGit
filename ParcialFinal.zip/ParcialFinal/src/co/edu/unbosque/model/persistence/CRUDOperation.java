package co.edu.unbosque.model.persistence;

public interface CRUDOperation {
	
	public void create(String... attribs);
	public void create(Object o);

	public String readAll();

	public boolean update(int index, String... attribs);

	public boolean delete(int index);
	public boolean delete(Object o);

}
