package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.ReptilDTO;


public class ReptilDAO implements CRUDOperation{
	
	private ArrayList<ReptilDTO> listaDeReptil;
	public final String FILENAME ="datosReptil.cvs";

	public ReptilDAO() {
		
		listaDeReptil = new ArrayList<>();

		// TODO Auto-generated constructor stub
	}
	String exit = "";

	public void writeOnFile() {
		exit = "";
		listaDeReptil.forEach((mamifero) -> {
			exit += mamifero.getNombre() + ";";
			exit += mamifero.getEdadMeses() + ";";
			exit += mamifero.getPesoKg() + ";";
			exit += mamifero.getCantidadDePatas() + "\n";
		});
		FileHandler.openAndWriteFile(FILENAME, exit);
	}


	
	@Override
	public void create(String... attribs) {
		// TODO Auto-generated method stub
		
		ReptilDTO newReptil = new ReptilDTO();
		newReptil.setNombre(attribs[0]);
		newReptil.setEdadMeses(Integer.parseInt(attribs[1]));
		newReptil.setPesoKg(Float.parseFloat(attribs[2]));
		newReptil.setCantidadDePatas(Integer.parseInt(attribs[3]));
		
		
	}
	@Override
	public void create(Object o) {
		
		listaDeReptil.add((ReptilDTO) o);
		// TODO Auto-generated method stub
		
	}
	
	int index = 0;

	@Override
	public String readAll() {
		index = 0;
		StringBuilder m = new StringBuilder();
		listaDeReptil.forEach(mamifero -> {
			m.append(index + " -> " + (mamifero.toString() + "\n"));
			index++;
		});
		return m.toString();
		
	}
	@Override
	public boolean update(int index, String... newData) {
		
		if (!newData[0].isBlank() || !newData[0].isEmpty()  || !newData[0].equals("")) {
			listaDeReptil.get(index).setNombre(newData[0]);
		}
		if (!newData[1].isBlank() || !newData[1].isEmpty()  || !newData[1].equals("")) {
			listaDeReptil.get(index).setEdadMeses(Integer.parseInt(newData[1]));
		}
		
		if (!newData[2].isBlank() || !newData[2].isEmpty()  || !newData[2].equals("")) {
			listaDeReptil.get(index).setPesoKg(Float.parseFloat(newData[2]));
		}
		if (!newData[3].isBlank() || !newData[3].isEmpty()  || !newData[3].equals("")) {
			listaDeReptil.get(index).setCantidadDePatas(Integer.parseInt(newData[3]));
		}
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean delete(int index) {
		// TODO Auto-generated method stub
		if (index < 0 || index >= listaDeReptil.size()) {
			return false;
		} else {
			listaDeReptil.remove(index);
			writeOnFile();

			return true;
		}
	}
	@Override
	public boolean delete(Object o) {
		
		ReptilDTO toDelete = (ReptilDTO) o;
		if (listaDeReptil.contains(toDelete)) {
			listaDeReptil.remove(toDelete);
			writeOnFile();

			return true;
		} else {
			return false;
		}
		// TODO Auto-generated method stub
	}
	
	public ArrayList<ReptilDTO> getListOfSharks() {
		return listaDeReptil;
	}

	public void setListOfSharks(ArrayList<ReptilDTO> listaDeReptil) {
		this.listaDeReptil = listaDeReptil;
	}



	public boolean update(int posicion, String newNombre, int newEdadMeses, float newPesoKg, String newCantPatas) {
		// TODO Auto-generated method stub
		return false;
	}


}

