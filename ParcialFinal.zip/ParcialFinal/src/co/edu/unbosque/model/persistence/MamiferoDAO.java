package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

import co.edu.unbosque.model.MamiferoDTO;


public class MamiferoDAO implements CRUDOperation{
	
	private ArrayList<MamiferoDTO> listaDeMamiferos;
	public final String FILENAME ="datosMamifero.cvs";

	
	public MamiferoDAO() {
		
		listaDeMamiferos = new ArrayList<>();

	

		}
	
	String exit = "";

	public void writeOnFile() {
		exit = "";
		listaDeMamiferos.forEach((mamifero) -> {
			exit += mamifero.getNombre() + ";";
			exit += mamifero.getEdadMeses() + ";";
			exit += mamifero.getPesoKg() + ";";
			exit += mamifero.getTipoDePelaje() + "\n";
		});
		FileHandler.openAndWriteFile(FILENAME, exit);
	}


	
	@Override
	public void create(String... attribs) {
		// TODO Auto-generated method stub
		
		MamiferoDTO newMamifero = new MamiferoDTO();
		newMamifero.setNombre(attribs[0]);
		newMamifero.setEdadMeses(Integer.parseInt(attribs[1]));
		newMamifero.setPesoKg(Float.parseFloat(attribs[2]));
		newMamifero.setTipoDePelaje(attribs[3]);
		
		
	}
	@Override
	public void create(Object o) {
		
		listaDeMamiferos.add((MamiferoDTO) o);
		// TODO Auto-generated method stub
		
	}
	
	int index = 0;

	@Override
	public String readAll() {
		index = 0;
		StringBuilder m = new StringBuilder();
		listaDeMamiferos.forEach(mamifero -> {
			m.append(index + " -> " + (mamifero.toString() + "\n"));
			index++;
		});
		return m.toString();
		
	}
	@Override
	public boolean update(int index, String... newData) {
		
		if (!newData[0].isBlank() || !newData[0].isEmpty()  || !newData[0].equals("")) {
			listaDeMamiferos.get(index).setNombre(newData[0]);
		}
		if (!newData[1].isBlank() || !newData[1].isEmpty()  || !newData[1].equals("")) {
			listaDeMamiferos.get(index).setEdadMeses(Integer.parseInt(newData[1]));
		}
		
		if (!newData[2].isBlank() || !newData[2].isEmpty()  || !newData[2].equals("")) {
			listaDeMamiferos.get(index).setPesoKg(Float.parseFloat(newData[2]));
		}
		if (!newData[3].isBlank() || !newData[3].isEmpty()  || !newData[3].equals("")) {
			listaDeMamiferos.get(index).setTipoDePelaje(newData[3]);
		}
		// TODO Auto-generated method stub
		return true;
	}
	@Override
	public boolean delete(int index) {
		// TODO Auto-generated method stub
		if (index < 0 || index >= listaDeMamiferos.size()) {
			return false;
		} else {
			listaDeMamiferos.remove(index);
			writeOnFile();

			return true;
		}
	}
	@Override
	public boolean delete(Object o) {
		
		MamiferoDTO toDelete = (MamiferoDTO) o;
		if (listaDeMamiferos.contains(toDelete)) {
			listaDeMamiferos.remove(toDelete);
			writeOnFile();

			return true;
		} else {
			return false;
		}
		// TODO Auto-generated method stub
	}
	
	public ArrayList<MamiferoDTO> getListOfSharks() {
		return listaDeMamiferos;
	}

	public void setListOfSharks(ArrayList<MamiferoDTO> listaDeMamiferos) {
		this.listaDeMamiferos = listaDeMamiferos;
	}



	public boolean update(int posicion, String newNombre, int newEdadMeses, float newPesoKg, String newPelaje) {
		// TODO Auto-generated method stub
		return false;
	}



	public void ordSelAscByPromedio() {
		// TODO Auto-generated method stub
		
	}


}
