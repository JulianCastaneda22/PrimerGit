package co.edu.unbosque.controller;

import co.edu.unbosque.model.MamiferoDTO;
import co.edu.unbosque.model.persistence.MamiferoDAO;
import co.edu.unbosque.model.persistence.ReptilDAO;
import co.edu.unbosque.view.Console;

public class Controller {

	private ReptilDAO rDao;
	private MamiferoDAO mDao;
	private Console con;

	public Controller() {
		// TODO Auto-generated constructor stub

		rDao = new ReptilDAO();
		mDao = new MamiferoDAO();
		con = new Console();
	}

	
	public void reptil() {
		
		cicloReptil: while (true) {
			con.printWithNewLine("1. Crear");
			con.printWithNewLine("2. Eliminar");
			con.printWithNewLine("3. Actualizar");
			con.printWithNewLine("4. Mostrar");
			int opcR = con.readInt();
			switch (opcR) {

			case 1: {
				con.quemarLinea();
				con.printWithNewLine("");
				con.printWithNewLine("Inserte el nombre:");
				String nombre = con.readWholeLine();

				con.printWithNewLine("Inserte la edad en MESES:");
				int edadMeses = con.readInt();

				con.printWithNewLine("Inserte el peso en KG");
				float pesoKg = con.readFloat();
				con.quemarLinea();

				con.printWithNewLine("Inserte cantidad de patas");
				String cantPatas = con.readWholeLine();
				con.quemarLinea();

				MamiferoDTO nuevo = new MamiferoDTO(nombre, edadMeses, pesoKg, cantPatas);

				rDao.create(nuevo);
				break;
			}
			case 2: {
				con.printWithNewLine("");
				con.printWithNewLine(
						"Inserte la posicion en que se encuentra el reptil que quiere eliminar, recuerde que la lista empieza desde + \\n\"\r\n"
								+ "							+ \"la posicion 0");
				int posicion = con.readInt();
				if (mDao.delete(posicion)) {
					con.printWithNewLine("El reptil ha sido eliminado con EXITO!!!");
				} else {
					con.printWithNewLine("Ese reptil no existe.");
				}
				break;
			}
			case 3: {
				con.printWithNewLine("");
				con.printWithNewLine(
						"Inserte la posicion en que se encuentra el reptil que quiere actualizar, recuerde que la lista empieza desde + \n"
								+ "la posicion 0");
				int posicion = con.readInt();

				con.quemarLinea();
				con.printWithNewLine("Inserte el nombre del animal:");
				String newNombre = con.readWholeLine();

				con.printWithNewLine("Inserte la edad en MESES:");
				int newEdadMeses = con.readInt();

				con.printWithNewLine("Inserte el peso en KG");
				float newPesoKg = con.readFloat();
				con.quemarLinea();

				con.printWithNewLine("Inserte la cantidad de patas");
				String newCantPatas = con.readWholeLine();

				boolean doneUpdate = rDao.update(posicion, newNombre, newEdadMeses, newPesoKg,  newCantPatas );

				if (doneUpdate) {
					con.printWithNewLine("Arbusto actualizado con EXITO!!!");
				} else {
					con.printWithNewLine("No se han actualizado los datos.");
				}

				break;
			}
			case 4: {
				con.printWithNewLine(rDao.readAll());
				break;
			}

			default:
				throw new IllegalArgumentException("Unexpected value: " + opcR);
			}

		}
		
	}
	public void mamifero() {
		cicloMamifero: while (true) {
			con.printWithNewLine("1. Crear");
			con.printWithNewLine("2. Eliminar");
			con.printWithNewLine("3. Actualizar");
			con.printWithNewLine("4. Mostrar");
			
			int opcM = con.readInt();
			switch (opcM) {

			case 1: {
				con.quemarLinea();
				con.printWithNewLine("");
				con.printWithNewLine("Inserte el nombre:");
				String nombre = con.readWholeLine();

				con.printWithNewLine("Inserte la edad en MESES:");
				int edadMeses = con.readInt();

				con.printWithNewLine("Inserte el peso en KG");
				float pesoKg = con.readFloat();
				con.quemarLinea();

				con.printWithNewLine("Inserte tipo de pelaje");
				String pelaje = con.readWholeLine();
				con.quemarLinea();

				MamiferoDTO nuevo = new MamiferoDTO(nombre, edadMeses, pesoKg, pelaje);

				mDao.create(nuevo);
				break;
			}
			case 2: {
				con.printWithNewLine("");
				con.printWithNewLine(
						"Inserte la posicion en que se encuentra el mamifero que quiere eliminar, recuerde que la lista empieza desde + \\n\"\r\n"
								+ "							+ \"la posicion 0");
				int posicion = con.readInt();
				if (mDao.delete(posicion)) {
					con.printWithNewLine("El mamifero ha sido eliminado con EXITO!!!");
				} else {
					con.printWithNewLine("Ese mamifero no existe.");
				}
				break;
			}
			case 3: {
				con.printWithNewLine("");
				con.printWithNewLine(
						"Inserte la posicion en que se encuentra el mamifero que quiere actualizar, recuerde que la lista empieza desde + \n"
								+ "la posicion 0");
				int posicion = con.readInt();

				con.quemarLinea();
				con.printWithNewLine("Inserte el nombre del animal:");
				String newNombre = con.readWholeLine();

				con.printWithNewLine("Inserte la edad en MESES:");
				int newEdadMeses = con.readInt();

				con.printWithNewLine("Inserte el peso en KG");
				float newPesoKg = con.readFloat();
				con.quemarLinea();

				con.printWithNewLine("Inserte tipo de pelaje");
				String newPelaje = con.readWholeLine();

				boolean doneUpdate = mDao.update(posicion, newNombre, newEdadMeses, newPesoKg,  newPelaje );

				if (doneUpdate) {
					con.printWithNewLine("Animal actualizado con EXITO!!!");
				} else {
					con.printWithNewLine("No se han actualizado los datos.");
				}

				break;
			}
			case 4: {
				con.printWithNewLine(mDao.readAll());
				
				con.printWithNewLine(" --- Lista de nombres organizadas de menor promedio a mayor promedio: ---");
				mDao.ordSelAscByPromedio(); 
				con.printWithNewLine(mDao.readAll());
				break;
			}

			default:
				throw new IllegalArgumentException("Unexpected value: " + opcM);
			}

		}
		

	}

	public void run() {
		cicloPrincipal: while (true) {
			con.printWithNewLine("//Animales//");
			con.printWithNewLine("");
			con.printWithNewLine("¿Que animal desea crear?");
			con.printWithNewLine("1. Mamifero");
			con.printWithNewLine("2. Reptil");
			int opcG = con.readInt();
			switch (opcG) {
			
			case 1:{
				//animal general
			}
			case 2: {
				mamifero();
				break;
			}
			case 3:{
				reptil();
				break;
			}
			
			}
		}

	}
}
